import threading
import time
import random
from datetime import datetime

try:
    import serial
except Exception as e:
    serial = None

from models import Sensor, CircularBuffer, DataRecord
from config import *

# Example Modbus-like commands for 4 sensors
MOD_CMDS = [
    [0x01,0x03,0x60,0x01,0x00,0x02,0x8B,0xCB], # CO2
    [0x02,0x03,0x60,0x01,0x00,0x02,0x8B,0xF8], # NH3
    [0x03,0x03,0x60,0x01,0x00,0x02,0x8A,0x29], # CH4
    [0x04,0x03,0x60,0x01,0x00,0x02,0x8B,0x9E], # H2S
]

class Collector:
    """Acquisition controller: manage serial port, threads, and aggregation."""
    def __init__(self, on_record_callback=None):
        self._on_record = on_record_callback  # callable(DataRecord)
        self._stop = threading.Event()
        self._comm_event = threading.Event()
        self._buf = CircularBuffer(BUFFER_SIZE)

        # Sensors
        self.co2 = Sensor("CO2")
        self.nh3 = Sensor("NH3")
        self.ch4 = Sensor("CH4")
        self.h2s = Sensor("H2S")

        self._ser = None
        self._threads = []
        self._index = 1

    # ---------- Internal thread loops ----------
    def _send_loop(self):
        while not self._stop.is_set():
            if self._ser and getattr(self._ser, "isOpen", lambda: False)():
                for cmd in MOD_CMDS:
                    try:
                        self._ser.write(bytes(cmd))
                    except Exception:
                        pass
                    time.sleep(0.5)
            time.sleep(SEND_INTERVAL_SEC)

    def _recv_loop(self):
        while not self._stop.is_set():
            if self._ser:
                try:
                    n = self._ser.in_waiting
                    if n and n > 0:
                        data = self._ser.read(n)
                        self._buf.append(data)
                except Exception:
                    pass
            time.sleep(READ_SLEEP_SEC)

    def _process_loop(self):
        hex_data = bytearray()
        while not self._stop.is_set():
            snap = self._buf.snapshot()
            if len(snap) >= 9:
                for _ in range(len(snap)):
                    try:
                        hex_data.append(self._buf.pop())
                    except Exception:
                        break

                # Very coarse frame example: xx 03 04 .... (replace with your real protocol)
                if len(hex_data) >= 6 and hex_data[1] == 0x03 and hex_data[2] == 0x04:
                    sid = hex_data[0]
                    val = int.from_bytes(hex_data[4:6], byteorder="big", signed=False)
                    if sid == 0x01:
                        self.co2.add_data(val); self.co2.set_attr("WR_flag", 1)
                    elif sid == 0x02:
                        self.nh3.add_data(val); self.nh3.set_attr("WR_flag", 1)
                    elif sid == 0x03:
                        self.ch4.add_data(val); self.ch4.set_attr("WR_flag", 1)
                    elif sid == 0x04:
                        self.h2s.add_data(val); self.h2s.set_attr("WR_flag", 1)
                    hex_data.clear()
                    self._comm_event.set()

            # When all four sensors have fresh data, emit a record
            if (self.co2.get_attr("WR_flag")==1 and
                self.nh3.get_attr("WR_flag")==1 and
                self.ch4.get_attr("WR_flag")==1 and
                self.h2s.get_attr("WR_flag")==1):
                
                # Reset flags
                self.co2.set_attr("WR_flag",0)
                self.nh3.set_attr("WR_flag",0)
                self.ch4.set_attr("WR_flag",0)
                self.h2s.set_attr("WR_flag",0)

                # Build record (temperature/humidity mocked here)
                rec = DataRecord(
                    index=self._index,
                    timestamp_str=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    temperature=round(random.uniform(10,20),1),
                    humidity=round(random.uniform(45,55),1),
                    co2=self.co2.get_data() or 0,
                    nh3=self.nh3.get_data() or 0,
                    ch4=self.ch4.get_data() or 0,
                    h2s=self.h2s.get_data() or 0
                )
                self._index += 1
                if callable(self._on_record):
                    try:
                        self._on_record(rec)
                    except Exception:
                        pass

            time.sleep(PROC_SLEEP_SEC)

    # ---------- Lifecycle ----------
    def start(self, port=SERIAL_PORT):
        if self._ser is not None:
            return
        if serial is None:
            raise RuntimeError("pyserial 未安装或导入失败，请先安装 pyserial。")
        self._stop.clear()
        self._ser = serial.Serial(
            port=port,
            baudrate=BAUDRATE,
            bytesize=serial.EIGHTBITS,
            stopbits=serial.STOPBITS_TWO,
            parity=serial.PARITY_NONE,
            timeout=0
        )
        self._threads = [
            threading.Thread(target=self._send_loop, name="sender", daemon=True),
            threading.Thread(target=self._recv_loop, name="receiver", daemon=True),
            threading.Thread(target=self._process_loop, name="processor", daemon=True),
        ]
        for t in self._threads:
            t.start()

    def stop(self):
        self._stop.set()
        for t in self._threads:
            try:
                t.join(timeout=1.5)
            except Exception:
                pass
        self._threads.clear()
        if self._ser:
            try:
                self._ser.close()
            finally:
                self._ser = None
