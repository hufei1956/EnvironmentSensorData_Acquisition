import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from collections import deque

from collect import Collector
from excel_writer import ExcelWriter
from config import UI_POLL_MS, SERIAL_PORT

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("传感器采集")
        self.geometry("620x420")

        # State vars
        self.port_var = tk.StringVar(value=SERIAL_PORT)
        self.outdir_var = tk.StringVar(value=".")
        self.status_var = tk.StringVar(value="未开始")
        self.count_var = tk.IntVar(value=0)

        # Top controls
        top = ttk.Frame(self, padding=10); top.pack(fill="x")
        ttk.Label(top, text="串口:").pack(side="left")
        ttk.Entry(top, textvariable=self.port_var, width=10).pack(side="left", padx=6)
        ttk.Button(top, text="输出目录", command=self.choose_dir).pack(side="left")
        ttk.Entry(top, textvariable=self.outdir_var, width=36).pack(side="left", padx=6)

        btns = ttk.Frame(self, padding=10); btns.pack(fill="x")
        self.start_btn = ttk.Button(btns, text="开始采集", command=self.start_collect)
        self.stop_btn  = ttk.Button(btns, text="停止采集", command=self.stop_collect, state="disabled")
        self.start_btn.pack(side="left", padx=4)
        self.stop_btn.pack(side="left", padx=4)

        stat = ttk.Frame(self, padding=10); stat.pack(fill="x")
        ttk.Label(stat, text="状态:").pack(side="left"); 
        ttk.Label(stat, textvariable=self.status_var).pack(side="left", padx=6)
        ttk.Label(stat, text="记录数:").pack(side="left", padx=(20,0)); 
        ttk.Label(stat, textvariable=self.count_var).pack(side="left", padx=6)

        # Preview box
        self.preview = tk.Text(self, height=14)
        self.preview.pack(fill="both", expand=True, padx=10, pady=6)
        self.preview.configure(state="disabled")

        # Dependencies
        self.collector = None
        self.writer = None
        self._queue = deque(maxlen=200)

        # Tick
        self.after(UI_POLL_MS, self._tick)

    def choose_dir(self):
        d = filedialog.askdirectory()
        if d:
            self.outdir_var.set(d)

    # Callback from collector when a record is ready
    def _on_record(self, rec):
        if self.writer:
            self.writer.write_record(rec)
        line = f"[{rec.index}] {rec.timestamp_str}  T={rec.temperature}°C  H={rec.humidity}%  CO2={rec.co2}  NH3={rec.nh3}  CH4={rec.ch4}  H2S={rec.h2s}"
        self._queue.append(line)
        self.count_var.set(rec.index)

    def start_collect(self):
        try:
            if self.collector is None:
                self.writer = ExcelWriter(visible=False)
                self.collector = Collector(on_record_callback=self._on_record)
            self.collector.start(port=self.port_var.get())
            self.status_var.set("采集中…")
            self.start_btn.config(state="disabled")
            self.stop_btn.config(state="normal")
        except Exception as e:
            messagebox.showerror("错误", f"启动失败：{e}")

    def stop_collect(self):
        try:
            if self.collector:
                self.collector.stop()
                self.collector = None
            saved = None
            if self.writer:
                saved = self.writer.save_and_close(self.outdir_var.get())
                self.writer = None
            self.status_var.set("已停止")
            self.start_btn.config(state="normal")
            self.stop_btn.config(state="disabled")
            if saved:
                messagebox.showinfo("已保存", f"已保存到：\n{saved}")
        except Exception as e:
            messagebox.showerror("错误", f"停止失败：{e}")

    def _tick(self):
        if self._queue:
            self.preview.configure(state="normal")
            while self._queue:
                self.preview.insert("end", self._queue.popleft() + "\n")
            self.preview.see("end")
            self.preview.configure(state="disabled")
        self.after(UI_POLL_MS, self._tick)
